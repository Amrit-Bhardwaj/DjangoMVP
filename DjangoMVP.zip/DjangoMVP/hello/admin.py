from django.contrib import admin

from .models import Airport, Flights


#1. Register the models with my admin site so that my admin site is able to
# manipulate Airports and flights
admin.site.register(Airport)
admin.site.register(Flights)


