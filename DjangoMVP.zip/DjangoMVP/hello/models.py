from django.db import models

# Create your models here.
class Airport(models.Model):
	code = models.CharField(max_length=3)
	city = models.CharField(max_length=64)

	def __str__(self):
		return f"{self.city} ({self.code})"

class Flights(models.Model):
	# here origin is going to point to some other Airport row's primary key.
	# What happens to origin field if that airport is deleted? This is set by CASCADE property that says
	# if the airport row is deleted then delete the correspoding Flights row as well.
    # related names help to get all the flight departures from an Airport
	origin = models.ForeignKey(Airport, on_delete=models.CASCADE, related_name="departures")
	destination = models.ForeignKey(Airport, on_delete=models.CASCADE, related_name="arrivals")
	duration = models.IntegerField()

# This method explains what this object should look like when printed from terminal or html page
	def __str__(self):
		return f"{self.id} - {self.origin} to {self.destination}"


class Passengers(models.Model):
	first = models.CharField(max_length=64)
	last = models.CharField(max_length=64)
	flights = models.ManyToManyField(Flights, blank=True, related_name="passengers")