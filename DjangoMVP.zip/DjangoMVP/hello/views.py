from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, Http404, HttpResponseRedirect
from hello.models import Flights, Passengers
from django.urls import reverse
#importing Http404 

# base path
## / HAETEOS
def index(request):
	
	flightList = {}
	try:
		flights = Flights.objects.all()

	except Flights.DoesNotExist:
		raise Http404("No Flights Available")

	flightNumber = 1
	for flight in flights:
		flightData = {}
		flightData["originCode"] = flight.origin.code
		flightData["originCityName"] = flight.origin.city
		flightData["destinationCode"] = flight.destination.code
		flightData["destinationCityName"] = flight.destination.city

		## This is used to get all the passengers of the flight
		#flightData["passengers"] = flight.passengers.all()

		## This is used to get all the non passengers of this flight
		#Passengers.objects.exclude(flights=flight).all()
		flightList[flightNumber] = flightData
		flightNumber += 1
	return JsonResponse(flightList)

## Get request based on flight id

def flight(request, flight_id):

	try:
		flight = Flights.objects.get(pk = flight_id)

		# if the flight does not exist thorws 404 error
	except Flights.DoesNotExist:
		raise Http404("Flight does not exist")

	flightDetails = {}
	flightDetails["originCode"] = flight.origin.code
	flightDetails["originCityName"] = flight.origin.city
	flightDetails["destinationCode"] = flight.destination.code
	flightDetails["destinationCityName"] = flight.destination.city
	return JsonResponse(flightDetails)

## Post request to book a flight
def book(request, flight_id):
	try:
		passeger_id = int(request.POST["passenger"])
		passenger = Passengers.objects.get(pk=passeger_id)
	except KeyError:
		# This occurs when the post body does not have 'passenger' key
		return HttpResponse("Key Error")
	except Passengers.DoesNotExist:
		# This occurs when passenger dne
		return HttpResponse("Passengers does not exist")
	except Flights.DoesNotExist:
		# This occurs when flight dne
		return HttpResponse("Flights does not exist")
	# Now we will do the registration of a passenger to a flight
	flight = Flights.objects.get(pk = flight_id)
	passenger.flights.add(flight)
	return HttpResponse("Booking Complete")

	# Going from the name of the URL to the actual url is called
    # reverse in django
    # Here we are redirecting the user to the flight url that shows
    # the newly added flight
	#return HttpResponseRedirect(reverse("flight", args(flight_id)))
    #flight = Flights.objects.get(pk=flight_id)

# POST request to perform login
def login_view(request):
	#1. Extract the username and password from POST body
	username = request.POST["username"]
	password = request.POST["password"]

	#2. authenticate is a django function
	user  = authenticate(request, username=username, password=password)
	# if the user is None that means authentication failed
	if user is not None:
		login(request, user)
		return HttpResponse("Login successfull!!")
	else:
		return HttpResponse("Login Failed")
	#if not request.user.is_authenticated:
		#return HttpResponse("User is not authenticated")
	#else:
		#return HttpResponse(f"user is authenticated. userName: {request.user}")


# logout and close the session

def logout_view(request):
	logout(request)
	return HttpResponse("logout invoked")











